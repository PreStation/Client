import React from "react"

import ResetPassword from "../../components/ResetPassword"

const ResetPasswordPage = () => {
  return <ResetPassword />
}

export default ResetPasswordPage