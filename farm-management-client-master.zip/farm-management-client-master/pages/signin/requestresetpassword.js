import React from "react"

import RequestResetPassword from "../../components/RequestResetPassword"

const Requestresetpassword = () => {
  return <RequestResetPassword />
}

export default Requestresetpassword