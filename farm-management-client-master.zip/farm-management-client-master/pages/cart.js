import React from "react";

const cart = () => {
  return <div>cart page</div>;
};

export default cart;
