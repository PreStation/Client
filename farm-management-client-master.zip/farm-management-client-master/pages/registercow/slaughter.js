import React, { useState } from "react";

import Nav from "../../components/RegisterCow/Nav/Nav";
import Form from "../../components/RegisterCow/7-listfeeds/index"
const ListregisPage = () => {

  return (
    <div>
      <Nav />
    <div>
      <Form/>
    </div>
    </div>
  );
};

export default ListregisPage;
