import React from 'react'

import Product from "../../components/Product"

const ProductId = () => {
  return <Product/>
}

export default ProductId
