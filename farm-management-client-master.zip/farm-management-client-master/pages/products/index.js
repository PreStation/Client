import React from 'react'

import Products from "../../components/Products"

const ProductsPage = () => {
  return <Products/>
}

export default ProductsPage
