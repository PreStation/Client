export const navbarHeight = 45;
export const navbarButtonHeight = 30;
export const sidebarWidth = 300;
export const searchModalWidth = 400;

