import {css} from "styled-components";

export const FromDiv = css`
  background-color: #fff;
  /* border: 1px solid rgba(0, 0, 0, 0.2); */
  border-radius: 10px;
  outline: 0;
  margin: auto;
  box-shadow: 0px 0px 2px grey;
`;
